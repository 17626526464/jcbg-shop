<?php
$data = array (
  0 => 
  array (
    'brand_id' => '204',
    'brand_name' => '金士顿',
    'letter' => 'J',
  ),
  1 => 
  array (
    'brand_id' => '93',
    'brand_name' => '同庆和堂',
    'letter' => 'T',
  ),
  2 => 
  array (
    'brand_id' => '141',
    'brand_name' => '钙尔奇',
    'letter' => 'G',
  ),
  3 => 
  array (
    'brand_id' => '153',
    'brand_name' => '康恩贝',
    'letter' => 'K',
  ),
  4 => 
  array (
    'brand_id' => '152',
    'brand_name' => '杰克琼斯',
    'letter' => 'J',
  ),
  5 => 
  array (
    'brand_id' => '151',
    'brand_name' => '姬芮',
    'letter' => 'J',
  ),
  6 => 
  array (
    'brand_id' => '150',
    'brand_name' => '华帝',
    'letter' => 'H',
  ),
  7 => 
  array (
    'brand_id' => '149',
    'brand_name' => '鸿星尔克',
    'letter' => 'H',
  ),
  8 => 
  array (
    'brand_id' => '148',
    'brand_name' => '宏基',
    'letter' => 'H',
  ),
  9 => 
  array (
    'brand_id' => '147',
    'brand_name' => '合生元',
    'letter' => 'H',
  ),
  10 => 
  array (
    'brand_id' => '145',
    'brand_name' => '海富通基金',
    'letter' => 'H',
  ),
  11 => 
  array (
    'brand_id' => '144',
    'brand_name' => '海飞丝',
    'letter' => 'H',
  ),
  12 => 
  array (
    'brand_id' => '143',
    'brand_name' => '工银瑞信',
    'letter' => 'G',
  ),
  13 => 
  array (
    'brand_id' => '142',
    'brand_name' => '哥弟',
    'letter' => 'G',
  ),
  14 => 
  array (
    'brand_id' => '155',
    'brand_name' => '兰蔻',
    'letter' => 'L',
  ),
  15 => 
  array (
    'brand_id' => '140',
    'brand_name' => '飞利浦',
    'letter' => 'F',
  ),
  16 => 
  array (
    'brand_id' => '139',
    'brand_name' => '飞科',
    'letter' => 'F',
  ),
  17 => 
  array (
    'brand_id' => '138',
    'brand_name' => '迪士尼',
    'letter' => 'D',
  ),
  18 => 
  array (
    'brand_id' => '137',
    'brand_name' => '达利园',
    'letter' => 'D',
  ),
  19 => 
  array (
    'brand_id' => '136',
    'brand_name' => '博时基金',
    'letter' => 'B',
  ),
  20 => 
  array (
    'brand_id' => '134',
    'brand_name' => '帮宝适',
    'letter' => 'B',
  ),
  21 => 
  array (
    'brand_id' => '132',
    'brand_name' => '阿玛尼',
    'letter' => 'A',
  ),
  22 => 
  array (
    'brand_id' => '131',
    'brand_name' => 'ZIPPO',
    'letter' => 'Z',
  ),
  23 => 
  array (
    'brand_id' => '130',
    'brand_name' => 'TP-LINL',
    'letter' => 'T',
  ),
  24 => 
  array (
    'brand_id' => '129',
    'brand_name' => 'NINE WEST',
    'letter' => 'N',
  ),
  25 => 
  array (
    'brand_id' => '126',
    'brand_name' => '戴尔',
    'letter' => 'D',
  ),
  26 => 
  array (
    'brand_id' => '178',
    'brand_name' => '文轩网',
    'letter' => 'W',
  ),
  27 => 
  array (
    'brand_id' => '209',
    'brand_name' => '佳能影像',
    'letter' => 'J',
  ),
  28 => 
  array (
    'brand_id' => '203',
    'brand_name' => '金龙鱼',
    'letter' => 'J',
  ),
  29 => 
  array (
    'brand_id' => '200',
    'brand_name' => '海贼王',
    'letter' => 'H',
  ),
  30 => 
  array (
    'brand_id' => '195',
    'brand_name' => '佳能',
    'letter' => 'J',
  ),
  31 => 
  array (
    'brand_id' => '194',
    'brand_name' => '乐视',
    'letter' => 'L',
  ),
  32 => 
  array (
    'brand_id' => '192',
    'brand_name' => '磨铁图书',
    'letter' => 'M',
  ),
  33 => 
  array (
    'brand_id' => '190',
    'brand_name' => '火星',
    'letter' => 'H',
  ),
  34 => 
  array (
    'brand_id' => '189',
    'brand_name' => '佳沪数码-华为',
    'letter' => 'J',
  ),
  35 => 
  array (
    'brand_id' => '188',
    'brand_name' => '戴尔-世纪笔记本',
    'letter' => 'D',
  ),
  36 => 
  array (
    'brand_id' => '186',
    'brand_name' => '新百伦',
    'letter' => 'X',
  ),
  37 => 
  array (
    'brand_id' => '180',
    'brand_name' => '小米',
    'letter' => 'X',
  ),
  38 => 
  array (
    'brand_id' => '154',
    'brand_name' => '匡威',
    'letter' => 'K',
  ),
  39 => 
  array (
    'brand_id' => '176',
    'brand_name' => '途牛',
    'letter' => 'T',
  ),
  40 => 
  array (
    'brand_id' => '167',
    'brand_name' => '千趣会',
    'letter' => 'Q',
  ),
  41 => 
  array (
    'brand_id' => '166',
    'brand_name' => '七匹狼',
    'letter' => 'Q',
  ),
  42 => 
  array (
    'brand_id' => '164',
    'brand_name' => '耐克',
    'letter' => 'N',
  ),
  43 => 
  array (
    'brand_id' => '163',
    'brand_name' => '魅族',
    'letter' => 'Z',
  ),
  44 => 
  array (
    'brand_id' => '160',
    'brand_name' => '美的',
    'letter' => 'M',
  ),
  45 => 
  array (
    'brand_id' => '159',
    'brand_name' => '麦斯威尔',
    'letter' => 'M',
  ),
  46 => 
  array (
    'brand_id' => '158',
    'brand_name' => '立邦',
    'letter' => 'L',
  ),
  47 => 
  array (
    'brand_id' => '157',
    'brand_name' => '李医生',
    'letter' => 'L',
  ),
  48 => 
  array (
    'brand_id' => '156',
    'brand_name' => '狼爪',
    'letter' => 'L',
  ),
  49 => 
  array (
    'brand_id' => '124',
    'brand_name' => '亿健',
    'letter' => 'Y',
  ),
  50 => 
  array (
    'brand_id' => '83',
    'brand_name' => '白兰氏',
    'letter' => 'B',
  ),
  51 => 
  array (
    'brand_id' => '96',
    'brand_name' => '金史密斯',
    'letter' => 'J',
  ),
  52 => 
  array (
    'brand_id' => '95',
    'brand_name' => 'BH (必艾奇)',
    'letter' => 'B',
  ),
  53 => 
  array (
    'brand_id' => '94',
    'brand_name' => '乐力',
    'letter' => 'L',
  ),
  54 => 
  array (
    'brand_id' => '92',
    'brand_name' => '一品玉',
    'letter' => 'Y',
  ),
  55 => 
  array (
    'brand_id' => '91',
    'brand_name' => '金奥力',
    'letter' => 'J',
  ),
  56 => 
  array (
    'brand_id' => '90',
    'brand_name' => '北大荒',
    'letter' => 'B',
  ),
  57 => 
  array (
    'brand_id' => '89',
    'brand_name' => '健安喜',
    'letter' => 'J',
  ),
  58 => 
  array (
    'brand_id' => '88',
    'brand_name' => '养生堂',
    'letter' => 'Y',
  ),
  59 => 
  array (
    'brand_id' => '87',
    'brand_name' => '汤臣倍健',
    'letter' => 'T',
  ),
  60 => 
  array (
    'brand_id' => '86',
    'brand_name' => '康比特',
    'letter' => 'K',
  ),
  61 => 
  array (
    'brand_id' => '85',
    'brand_name' => '喜瑞',
    'letter' => 'X',
  ),
  62 => 
  array (
    'brand_id' => '84',
    'brand_name' => '同仁堂',
    'letter' => 'T',
  ),
  63 => 
  array (
    'brand_id' => '97',
    'brand_name' => '斯伯丁',
    'letter' => 'S',
  ),
  64 => 
  array (
    'brand_id' => '82',
    'brand_name' => '李宁',
    'letter' => 'L',
  ),
  65 => 
  array (
    'brand_id' => '81',
    'brand_name' => '宝姿',
    'letter' => 'B',
  ),
  66 => 
  array (
    'brand_id' => '80',
    'brand_name' => 'Dior',
    'letter' => 'D',
  ),
  67 => 
  array (
    'brand_id' => '79',
    'brand_name' => 'justyle',
    'letter' => 'J',
  ),
  68 => 
  array (
    'brand_id' => '78',
    'brand_name' => '猫人',
    'letter' => 'M',
  ),
  69 => 
  array (
    'brand_id' => '77',
    'brand_name' => '阿迪达斯',
    'letter' => 'A',
  ),
  70 => 
  array (
    'brand_id' => '76',
    'brand_name' => '金利来',
    'letter' => 'J',
  ),
  71 => 
  array (
    'brand_id' => '75',
    'brand_name' => '佐丹奴',
    'letter' => 'Z',
  ),
  72 => 
  array (
    'brand_id' => '74',
    'brand_name' => '梦特娇',
    'letter' => 'M',
  ),
  73 => 
  array (
    'brand_id' => '73',
    'brand_name' => '她他/tata',
    'letter' => 'T',
  ),
  74 => 
  array (
    'brand_id' => '72',
    'brand_name' => 'ELLE HOME',
    'letter' => 'E',
  ),
  75 => 
  array (
    'brand_id' => '109',
    'brand_name' => '诺基亚',
    'letter' => 'N',
  ),
  76 => 
  array (
    'brand_id' => '71',
    'brand_name' => 'esprit',
    'letter' => 'E',
  ),
  77 => 
  array (
    'brand_id' => '122',
    'brand_name' => 'Five Plus',
    'letter' => 'F',
  ),
  78 => 
  array (
    'brand_id' => '118',
    'brand_name' => 'HTC',
    'letter' => 'H',
  ),
  79 => 
  array (
    'brand_id' => '117',
    'brand_name' => '阿尔卡特',
    'letter' => 'A',
  ),
  80 => 
  array (
    'brand_id' => '116',
    'brand_name' => '伊莱克斯',
    'letter' => 'Y',
  ),
  81 => 
  array (
    'brand_id' => '115',
    'brand_name' => '西门子',
    'letter' => 'X',
  ),
  82 => 
  array (
    'brand_id' => '114',
    'brand_name' => '海尔',
    'letter' => 'H',
  ),
  83 => 
  array (
    'brand_id' => '113',
    'brand_name' => 'LG',
    'letter' => 'L',
  ),
  84 => 
  array (
    'brand_id' => '112',
    'brand_name' => '海信',
    'letter' => 'H',
  ),
  85 => 
  array (
    'brand_id' => '111',
    'brand_name' => '摩托罗拉',
    'letter' => 'M',
  ),
  86 => 
  array (
    'brand_id' => '110',
    'brand_name' => '松下电器',
    'letter' => 'S',
  ),
  87 => 
  array (
    'brand_id' => '125',
    'brand_name' => '华为',
    'letter' => 'H',
  ),
  88 => 
  array (
    'brand_id' => '108',
    'brand_name' => '苹果',
    'letter' => 'P',
  ),
  89 => 
  array (
    'brand_id' => '107',
    'brand_name' => '三星',
    'letter' => 'S',
  ),
  90 => 
  array (
    'brand_id' => '106',
    'brand_name' => '开普特',
    'letter' => 'K',
  ),
  91 => 
  array (
    'brand_id' => '105',
    'brand_name' => '玛克家纺',
    'letter' => 'M',
  ),
  92 => 
  array (
    'brand_id' => '104',
    'brand_name' => '亨泰尔克',
    'letter' => 'H',
  ),
  93 => 
  array (
    'brand_id' => '103',
    'brand_name' => 'Masentek',
    'letter' => 'M',
  ),
  94 => 
  array (
    'brand_id' => '102',
    'brand_name' => '欧亚马',
    'letter' => 'O',
  ),
  95 => 
  array (
    'brand_id' => '101',
    'brand_name' => '皮克朋',
    'letter' => 'P',
  ),
  96 => 
  array (
    'brand_id' => '100',
    'brand_name' => '乔山',
    'letter' => 'Q',
  ),
  97 => 
  array (
    'brand_id' => '99',
    'brand_name' => '火枫',
    'letter' => 'H',
  ),
  98 => 
  array (
    'brand_id' => '98',
    'brand_name' => '皮尔瑜伽',
    'letter' => 'P',
  ),
);
?>