<?php
$data = array (
  'goods_list' => 
  array (
    903 => 
    array (
      'goods_id' => '903',
      'goods_name' => '正品直邮Hermes爱马仕2017新款男鞋 时尚真皮休闲鞋H171325ZH02 7495',
      'goods_thumb' => 'http://kjwbb.oss-cn-hangzhou.aliyuncs.com/images/202010/thumb_img/903_thumb_G_1604059222001.jpg',
      'url' => 'goods.php?id=903',
      'shop_price' => '<em>¥</em>798.00',
      'promote_price' => '',
    ),
    684 => 
    array (
      'goods_id' => '684',
      'goods_name' => '【情侣款】Camel骆驼男靴 时尚潮流英伦风马丁靴高帮皮靴 爆卖1万双！ 情侣马丁靴 好评如潮',
      'goods_thumb' => 'http://kjwbb.oss-cn-hangzhou.aliyuncs.com/images/201703/thumb_img/0_thumb_G_1489109583798.jpg',
      'url' => 'goods.php?id=684',
      'shop_price' => '<em>¥</em>555.00',
      'promote_price' => '',
    ),
    685 => 
    array (
      'goods_id' => '685',
      'goods_name' => '春季马丁靴男真皮男靴黄靴工装军靴韩版短靴沙漠靴高帮男鞋大黄靴 头层牛皮',
      'goods_thumb' => 'http://kjwbb.oss-cn-hangzhou.aliyuncs.com/images/201703/thumb_img/0_thumb_G_1489109633806.jpg',
      'url' => 'goods.php?id=685',
      'shop_price' => '<em>¥</em>1000.00',
      'promote_price' => '',
    ),
    681 => 
    array (
      'goods_id' => '681',
      'goods_name' => '2016秋冬季新款尖头粗跟短靴女高跟真皮加绒中跟马丁靴女靴子女鞋 优质全头层牛皮，品质女鞋',
      'goods_thumb' => 'http://kjwbb.oss-cn-hangzhou.aliyuncs.com/images/201703/thumb_img/0_thumb_G_1489109130174.jpg',
      'url' => 'goods.php?id=681',
      'shop_price' => '<em>¥</em>458.00',
      'promote_price' => '',
    ),
    678 => 
    array (
      'goods_id' => '678',
      'goods_name' => '盛装舞步新款女包新款时尚潮流旅游韩版大容量轻巧手提旅行包袋 正品保证,时尚轻巧,耐用,多层设计',
      'goods_thumb' => 'http://kjwbb.oss-cn-hangzhou.aliyuncs.com/images/201703/thumb_img/0_thumb_G_1489108952500.jpg',
      'url' => 'goods.php?id=678',
      'shop_price' => '<em>¥</em>500.00',
      'promote_price' => '',
    ),
  ),
  'page_count' => 1,
  'record_count' => 5,
);
?>