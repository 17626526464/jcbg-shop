<?php
$data = array (
  'data' => 1,
);
?>