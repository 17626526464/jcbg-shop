
<ul class="gm-f-tab" ectype="gmf-tab">
    <li class="curr" rev="0"><a href="javascript:;"><?php echo $this->_var['lang']['all_attribute']; ?><em>(<?php echo $this->_var['comment_allCount']; ?>)</em></a></li>
    <li rev="1"><a href="javascript:;"><?php echo $this->_var['lang']['Rate']; ?><em>(<?php echo $this->_var['comment_good']; ?>)</em></a></li>
    <li rev="2"><a href="javascript:;"><?php echo $this->_var['lang']['zhong_p']; ?><em>(<?php echo $this->_var['comment_middle']; ?>)</em></a></li>
    <li rev="3" class="last"><a href="javascript:;"><?php echo $this->_var['lang']['Bad']; ?><em>(<?php echo $this->_var['comment_short']; ?>)</em></a></li>
</ul>