
<div class="duibi_box" id="slideTxtBox">
    <div class="parWarp">
        <div class="parTit"><?php echo $this->_var['lang']['Contrast_bar']; ?></div>
        <div class="parBd">
            <div class="slideBox5" id="duibilan">
                <div id="diff-items" class="diff-items clearfix">
                    <dl class="hasItem" id="compare_goods1">  
                        <dt><h1>1</h1></dt>
                        <dd><span class="ts"><?php echo $this->_var['lang']['Continue_add_dui']; ?></span></dd>
                    </dl>
                    <dl class="hasItem" id="compare_goods2">  
                        <dt><h1>2</h1></dt>
                        <dd><span class="ts"><?php echo $this->_var['lang']['Continue_add_dui']; ?></span></dd>
                    </dl>
                    <dl class="hasItem" id="compare_goods3">  
                        <dt><h1>3</h1></dt>
                        <dd><span class="ts"><?php echo $this->_var['lang']['Continue_add_dui']; ?></span></dd>
                    </dl>
                    <dl class="hasItem" id="compare_goods4">  
                        <dt><h1>4</h1></dt>
                        <dd><span class="ts"><?php echo $this->_var['lang']['Continue_add_dui']; ?></span></dd>
                    </dl>
                </div>
                <div class="diff-operate">
                	<a id="compare_button" class="compare-active"></a>
					<a id="qingkong" class="del-items"><?php echo $this->_var['lang']['empty_contrast']; ?></a>
                    <a href="javascript:;" class="hide-me" ectype="db_hide"><?php echo $this->_var['lang']['hidden']; ?></a>
                </div>
            </div>
        </div>
    </div>
</div>


