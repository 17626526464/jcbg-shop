<div class="gm-title">
    <h3>网友讨论圈</h3>
    <div class="gm-f-tab">
        <a href="javascript:void(0);" class="dis_type curr" rev="0" revType="1"><?php echo $this->_var['lang']['allcount']; ?>(<?php echo $this->_var['all_count']; ?>)</a>
        <a href="javascript:void(0);" class="dis_type" rev="4" revType="1"><?php echo $this->_var['lang']['s_count']; ?>(<?php echo $this->_var['s_count']; ?>)</a>
        <a href="javascript:void(0);" class="dis_type" rev="1" revType="1"><?php echo $this->_var['lang']['t_count']; ?>(<?php echo $this->_var['t_count']; ?>)</a>
        <a href="javascript:void(0);" class="dis_type" rev="2" revType="1"><?php echo $this->_var['lang']['w_count']; ?>(<?php echo $this->_var['w_count']; ?>)</a>
        <a href="javascript:void(0);" class="dis_type" rev="3" revType="1"><?php echo $this->_var['lang']['q_count']; ?>(<?php echo $this->_var['q_count']; ?>)</a>
    </div>
</div>